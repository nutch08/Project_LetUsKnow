﻿Imports System.Data
Imports System.Data.SqlClient
Partial Class edit
    Inherits System.Web.UI.Page

   
    Private connectionString As String = ConfigurationManager.ConnectionStrings("ConnectionString").ConnectionString()
    Protected Sub Button1_Click(sender As Object, e As EventArgs) Handles Button1.Click
        Dim idCustomer As String = Request.QueryString("idCustomer").ToString()
        Dim sql As String
        Dim imageProfile As String
        imageProfile = FileUpload1.FileName
        FileUpload1.SaveAs(Server.MapPath("images/" & imageProfile))
        sql = "UPDATE Customer set "



        sql = sql & " identificationNumber = '" & TextBox2.Text & "',"
        sql = sql & " passport = '" & TextBox3.Text & "',"
        sql = sql & " firstname = '" & TextBox4.Text & "',"
        sql = sql & " lastname = '" & TextBox5.Text & "',"
        sql = sql & " gender = '" & TextBox6.Text & "',"
        sql = sql & " nationality = '" & TextBox7.Text & "',"
        sql = sql & " address = '" & TextBox8.Text & "',"
        sql = sql & " hometown = '" & TextBox9.Text & "',"
        sql = sql & " birthday = '" & TextBox10.Text & "',"
        sql = sql & " tel = '" & TextBox11.Text & "',"
        sql = sql & " fax = '" & TextBox12.Text & "',"
        sql = sql & " email = '" & TextBox13.Text & "',"
        sql = sql & " facebook = '" & TextBox14.Text & "',"
        sql = sql & " emergencyContact = '" & TextBox15.Text & "',"
        sql = sql & " image_profile = '" & imageProfile & "',"
        sql = sql & " passcode = '" & TextBox16.Text & "'"


        sql = sql & " WHERE idCustomer = " & idCustomer

        Dim comm As New SqlCommand
        Dim conn As New SqlConnection(connectionString)
        comm.CommandText = sql
        comm.CommandType = CommandType.Text
        comm.Connection = conn
        conn.Open()
        comm.ExecuteNonQuery()
        conn.Close()
        Response.Redirect("member_data.aspx")
    End Sub

    Protected Sub Page_Load(sender As Object, e As EventArgs) Handles Me.Load
        If Not Page.IsPostBack Then
            connectionString = ConfigurationManager.ConnectionStrings("ConnectionString").ConnectionString()
            Dim CustomerID As String
            Dim html As String
            CustomerID = Request.QueryString("idCustomer").ToString()
            Dim sql As String
            sql = "select * from Customer where idCustomer=" & CustomerID
            Dim comm As New SqlCommand
            Dim conn As New SqlConnection(connectionString)
            comm.CommandText = sql
            comm.CommandType = CommandType.Text
            comm.Connection = conn
            conn.Open()
            Dim dr As SqlDataReader
            dr = comm.ExecuteReader()
            While dr.Read



                html = "<img src='images/" & dr("image_profile").ToString & "' width='200px'>"
                Literal2.Text = html
                TextBox2.Text = dr("identificationNumber").ToString()
                TextBox3.Text = dr("passport").ToString()
                TextBox4.Text = dr("firstname").ToString()
                TextBox5.Text = dr("lastname").ToString()
                TextBox6.Text = dr("gender").ToString()
                TextBox7.Text = dr("nationality").ToString()
                TextBox8.Text = dr("address").ToString()
                TextBox9.Text = dr("hometown").ToString()
                TextBox10.Text = dr("birthday").ToString()
                TextBox11.Text = dr("tel").ToString()
                TextBox12.Text = dr("fax").ToString()
                TextBox13.Text = dr("email").ToString()
                TextBox14.Text = dr("facebook").ToString()
                TextBox15.Text = dr("emergencyContact").ToString()
                TextBox16.Text = dr("passcode").ToString()


            End While


            conn.Close()
        End If
    End Sub

    
   
    
    Protected Sub Calendar1_SelectionChanged(sender As Object, e As EventArgs) Handles Calendar1.SelectionChanged



    End Sub
End Class
