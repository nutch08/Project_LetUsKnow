﻿Imports System.Data
Imports System.Data.SqlClient
Partial Class add
    Inherits System.Web.UI.Page

    
  
    Private connectionString As String = ConfigurationManager.ConnectionStrings("ConnectionString").ConnectionString()
    
    Protected Sub btnAddData_Click(sender As Object, e As EventArgs) Handles btnAddData.Click
        Dim imageProfile As String
        imageProfile = FileUpload1.FileName
        FileUpload1.SaveAs(Server.MapPath("images/" & imageProfile))

        Dim sql As String
        sql = "INSERT INTO Customer(identificationNumber, passport, firstname, lastname, gender, nationality, address, hometown, birthday, tel, fax, email, facebook, emergencyContact, passcode, image_profile) "
        sql = sql & "VALUES('" & txbIden.Text & "','" & txbPassport.Text & "','" & txtFirstname.Text & "','" & txtLastname.Text & "','" &
            txtGender.Text & "','" & txtNation.Text & "','" & txtAddress.Text & "','" & txtHometown.Text & "','" &
            txtBirthday.Text & "','" & txtTel.Text & "','" & txtFax.Text & "','" & txtEmail.Text & "','" &
            txtFace.Text & "','" & txtEmer.Text & "','" & txtPasscode.Text & "','" & imageProfile & "') "

        Dim conn As New SqlConnection(connectionString)
        Dim comm As New SqlCommand
        comm.CommandText = sql
        comm.CommandType = CommandType.Text
        comm.Connection = conn
        conn.Open()

        comm.ExecuteNonQuery()

        conn.Close()

        Response.Redirect("member_data.aspx")


    End Sub

    Protected Sub txbCustID_TextChanged(sender As Object, e As EventArgs) Handles txbPassport.TextChanged

    End Sub

    Protected Sub Page_Load(sender As Object, e As EventArgs) Handles Me.Load

    End Sub
End Class
