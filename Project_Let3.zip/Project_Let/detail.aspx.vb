﻿Imports System.Data
Imports System.Data.SqlClient
Partial Class detail
    Inherits System.Web.UI.Page
    Private connectionString As String = ConfigurationManager.ConnectionStrings("ConnectionString").ConnectionString()

    Protected Sub Page_Load(sender As Object, e As EventArgs) Handles Me.Load
        If Not Page.IsPostBack Then

            Dim idCustomer As String
            Dim html As String
            idCustomer = Request.QueryString("idCustomer").ToString()
            Dim sql As String
            sql = "select * from Customer where idCustomer=" & idCustomer
            Dim comm As New SqlCommand
            Dim conn As New SqlConnection(connectionString)
            comm.CommandText = sql
            comm.CommandType = CommandType.Text
            comm.Connection = conn
            conn.Open()
            Dim dr As SqlDataReader
            dr = comm.ExecuteReader()
            While dr.Read

                Label24.Text = dr("identificationNumber").ToString()
                Label25.Text = dr("Passport").ToString()

                Label26.Text = dr("firstname").ToString()
                Label27.Text = dr("lastname").ToString()
                Label28.Text = dr("gender").ToString()
                Label29.Text = dr("nationality").ToString()
                Label30.Text = dr("address").ToString()
                Label31.Text = dr("hometown").ToString()
                Label32.Text = dr("birthday").ToString()
                Label33.Text = dr("tel").ToString()
                Label34.Text = dr("fax").ToString()
                Label35.Text = dr("email").ToString()
                Label36.Text = dr("facebook").ToString()
                Label37.Text = dr("emergencyContact").ToString()
                Label38.Text = dr("passcode").ToString()


                html = "<img src='images/" & dr("image_profile").ToString & "' width='200px'>"
                Literal2.Text = html
            End While


            conn.Close()
        End If
    End Sub


    Protected Sub Button1_Click(sender As Object, e As EventArgs) Handles Button1.Click
        Response.Redirect("member_data.aspx")

    End Sub

    Protected Sub Button2_Click(sender As Object, e As EventArgs) Handles Button2.Click
        Response.Redirect("edit.aspx")
    End Sub
End Class
