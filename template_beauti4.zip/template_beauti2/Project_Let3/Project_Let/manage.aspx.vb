﻿Imports System.Data.SqlClient
Imports System.Data

Partial Class manage
    Inherits System.Web.UI.Page

    Dim datasource As String = ""

    Private connectionString As String = ConfigurationManager.ConnectionStrings("ConnectionString").ConnectionString()

    Protected Sub Button5_Click(sender As Object, e As EventArgs) Handles Button5.Click

        
     

        Dim sql As String
        sql = "INSERT INTO ManageType(Day_Manage, Month_Manage, Year_Manage, VillaName_Manage, Type_Manage, People_Manage) "
        sql = sql & "VALUES('" & ddl_Day.Text & "','" & ddl_Month.Text & "','" & ddl_Year.Text & "','" & txtVillaName.Text & "',"
        sql = sql & "'" & ddlType1.Text & "','" & ddlPeople1.Text & "') "

        Dim conn As New SqlConnection(connectionString)
        Dim comm As New SqlCommand
        comm.CommandText = sql
        comm.CommandType = CommandType.Text
        comm.Connection = conn
        conn.Open()

        comm.ExecuteNonQuery()

        conn.Close()


    End Sub
End Class
