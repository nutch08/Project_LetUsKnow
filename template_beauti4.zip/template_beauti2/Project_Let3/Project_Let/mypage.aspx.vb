﻿
Partial Class mypage
    Inherits System.Web.UI.Page

End Class
