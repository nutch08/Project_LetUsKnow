﻿Imports System.Data
Imports System.Data.SqlClient
Partial Class member_data
    Inherits System.Web.UI.Page
    Private connectionString As String = ConfigurationManager.ConnectionStrings("ConnectionString").ConnectionString()
   ' Protected Sub GridView1_SelectedIndexChanged(sender As Object, e As EventArgs) Handles GridView1.SelectedIndexChanged
    '    Dim sql As String
    '   sql = "INSERT INTO CustomerID(identificationNumber, passport, firstname, lastname, gender, nationality, address, hometown, birthday, tel, fax, email, facebook, emergencyContact, image_profile) "
    '  sql = sql & " VALUES INTO "

    '    Dim conn As New SqlConnection(connectionString)
    '   Dim comm As New SqlCommand
    '  comm.CommandText = sql
    ' comm.CommandType = CommandType.Text
    'comm.Connection = conn
    'conn.Open()

    '    comm.ExecuteNonQuery()

    '    conn.Close()

    '   Response.Redirect("member_data.aspx")
    'End 


   
    Protected Sub GridView1_SelectedIndexChanged(sender As Object, e As EventArgs) Handles GridView1.SelectedIndexChanged

        Dim sql As String
        sql = "INSERT INTO CustomerID(idCustomer, identificationNumber, passport, firstname, lastname, gender, nationality, address, hometown, birthday, tel, fax, email, facebook, emergencyContact, image_profile) "
        sql = sql & " VALUES INTO "

        Dim conn As New SqlConnection(connectionString)
        Dim comm As New SqlCommand
        comm.CommandText = sql
        comm.CommandType = CommandType.Text
        comm.Connection = conn
        conn.Open()

        comm.ExecuteNonQuery()

        conn.Close()

        Response.Redirect("member_data.aspx")
    End Sub


    

    Protected Sub BtnAdd_Click(sender As Object, e As EventArgs) Handles btnAdd.Click

        Response.Redirect("add.aspx")
    End Sub
End Class
