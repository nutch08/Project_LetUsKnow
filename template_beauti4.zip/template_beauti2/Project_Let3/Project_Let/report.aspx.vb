﻿
Partial Class report
    Inherits System.Web.UI.Page

End Class
