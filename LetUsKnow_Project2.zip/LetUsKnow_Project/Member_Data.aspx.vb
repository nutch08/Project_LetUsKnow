﻿
Partial Class Member_Data
    Inherits System.Web.UI.Page

End Class
