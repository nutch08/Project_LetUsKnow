﻿
Partial Class Edit
    Inherits System.Web.UI.Page

End Class
