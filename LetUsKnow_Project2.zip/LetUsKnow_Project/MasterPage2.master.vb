﻿
Partial Class MasterPage2
    Inherits System.Web.UI.MasterPage
End Class

