﻿
Imports System.Data
Imports System.Data.SqlClient
Imports MySql.Data.MySqlClient


Partial Class MasterPage
    Inherits System.Web.UI.MasterPage
    Private MySQLConnection As MySqlConnection
 

    Protected Sub Passcode_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles Passcode.Click
        MySQLConnection = New MySqlConnection
        MySQLConnection.ConnectionString = "Server=localhost; User Id=root; Password=root; Database=letusknow"
        MySQLConnection.Open()

        Dim sql As String

        sql = "SELECT * FROM employee where passcode ='" & Login.Text & "'"


        Dim sqlCommand As New MySqlCommand

        sqlCommand.Connection = MySQLConnection
        sqlCommand.CommandText = sql


        Response.Redirect("Index.aspx")

        MySQLConnection.Close()

    End Sub



End Class

