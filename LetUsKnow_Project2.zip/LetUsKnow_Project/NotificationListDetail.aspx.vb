﻿
Partial Class NotificationListDetail
    Inherits System.Web.UI.Page

End Class
