﻿
Partial Class Add
    Inherits System.Web.UI.Page

End Class
