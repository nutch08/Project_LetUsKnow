﻿
Partial Class Report
    Inherits System.Web.UI.Page

End Class
