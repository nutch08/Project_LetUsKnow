﻿
Partial Class Detail
    Inherits System.Web.UI.Page

End Class
