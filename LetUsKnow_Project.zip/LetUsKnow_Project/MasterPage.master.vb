﻿
Imports System.Data
Imports System.Data.SqlClient
Imports MySql.Data.MySqlClient


Partial Class MasterPage
    Inherits System.Web.UI.MasterPage

 

    Protected Sub Passcode_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles Passcode.Click

    

    End Sub
End Class

