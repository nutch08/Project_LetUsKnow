﻿
Partial Class Manage
    Inherits System.Web.UI.Page

End Class
