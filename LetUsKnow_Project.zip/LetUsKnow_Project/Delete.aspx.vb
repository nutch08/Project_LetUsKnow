﻿
Partial Class Delete
    Inherits System.Web.UI.Page

End Class
