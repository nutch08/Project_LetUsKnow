﻿Imports MySql.Data.MySqlClient
Imports System.Data.SqlClient

Partial Class _Default
    Inherits System.Web.UI.Page
    Private MySQLConnection As MySqlConnection
    Protected Sub Passcode_Click(sender As Object, e As EventArgs) Handles Passcode.Click

        MySQLConnection = New MySqlConnection
        MySQLConnection.ConnectionString = "Server=localhost; User Id=root; Password=root; Database=letusknow"
        MySQLConnection.Open()

        Dim sql As String

        sql = "SELECT * FROM employee where passcode ='" & Login.Text & "'"


        Dim sqlCommand As New MySqlCommand
        Dim intNumRow As Integer

        sqlCommand.Connection = MySQLConnection
        sqlCommand.CommandText = sql
        intNumRow = sqlCommand.ExecuteScalar


        If intNumRow > 0 Then
            Response.Redirect("Index.aspx")
        Else

        End If





        MySQLConnection.Close()
    End Sub
End Class
