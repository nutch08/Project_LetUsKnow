﻿
Partial Class notification
    Inherits System.Web.UI.Page


End Class
