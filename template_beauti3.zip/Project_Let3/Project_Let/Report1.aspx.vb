﻿
Partial Class Report1
    Inherits System.Web.UI.Page

End Class
