﻿Imports System.Data
Imports System.Data.SqlClient
Partial Class notificationlistdetail
    Inherits System.Web.UI.Page
    Private connectionString As String = ConfigurationManager.ConnectionStrings("ConnectionString").ConnectionString()
    Protected Sub Page_Load(sender As Object, e As EventArgs) Handles Me.Load


        If Not Page.IsPostBack Then

            Dim idNotification As String
            Dim html As String
            idNotification = Request.QueryString("idNotification").ToString()
            Dim sql As String
            sql = "select * from Notification where idNotification=" & idNotification
            Dim comm As New SqlCommand
            Dim conn As New SqlConnection(connectionString)
            comm.CommandText = sql
            comm.CommandType = CommandType.Text
            comm.Connection = conn
            conn.Open()
            Dim dr As SqlDataReader
            dr = comm.ExecuteReader()
            While dr.Read


                Label1.Text = dr("name").ToString()

                TextBox1.Text = dr("comment").ToString()
                TextBox3.Text = dr("latitude").ToString()
                TextBox2.Text = dr("longitude").ToString()
               

            


                html = "<img src='images/" & dr("image").ToString & "' width='100px'>"
                Literal2.Text = html
            End While


            conn.Close()
        End If
    End Sub


    
End Class
