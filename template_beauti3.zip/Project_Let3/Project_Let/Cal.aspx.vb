﻿
Partial Class Cal
    Inherits System.Web.UI.Page

End Class
