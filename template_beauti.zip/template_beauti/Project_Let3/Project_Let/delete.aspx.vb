﻿Imports System.Data
Imports System.Data.SqlClient
Partial Class delete
    Inherits System.Web.UI.Page
 
     Private connectionString As String = ConfigurationManager.ConnectionStrings("ConnectionString").ConnectionString()
    Private Sub Page_Load(sender As Object, e As EventArgs) Handles Me.Load
        Dim sql As String
        Dim idCustomer As String = Request.QueryString("idCustomer").ToString()
        sql = "DELETE FROM Customer WHERE idCustomer=" & idCustomer

        Dim comm As New SqlCommand
        Dim conn As New SqlConnection(connectionString)
        comm.CommandText = sql
        comm.CommandType = CommandType.Text
        comm.Connection = conn
        conn.Open()
        comm.ExecuteNonQuery()
        conn.Close()

        Response.Redirect("member_data.aspx")

    End Sub

    
End Class
